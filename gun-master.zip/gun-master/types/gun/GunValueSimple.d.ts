export type GunValueSimple = string | number | boolean | null;
