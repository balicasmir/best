export interface IGunOnEvent {
  off(): void;
}
