export type GunOptionsOnce = Partial<{
  /**
   * controls the asynchronous timing
   */
  wait: number;
}>;
