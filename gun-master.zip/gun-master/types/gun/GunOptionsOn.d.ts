export type GunOptionsOn = Partial<
  | {
      change: boolean;
    }
  | boolean
>;
