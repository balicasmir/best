export type pany = Partial<any>;
