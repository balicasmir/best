export type GunOptionsPut = Partial<{
  opt: {
    /** certificate that gives other people write permission */ cert: string;
  };
}>;
