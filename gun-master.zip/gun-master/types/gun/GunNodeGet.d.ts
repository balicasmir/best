export type GunNodeGet = {
  /** Node path */
  '#': string;
  /** Leaf name */
  '.': string;
};
