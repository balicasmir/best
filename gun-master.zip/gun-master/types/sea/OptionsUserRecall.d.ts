export type OptionsUserRecall = { sessionStorage: boolean };
