import Gun from '../..';

//Documentation should work

const gun = new Gun();

gun.user().leave();
