import Gun from '../..';

const gun = new Gun();
gun.user().recall({ sessionStorage: true });
