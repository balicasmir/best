import Gun from '../..';

var gun = new Gun();
gun.user('publicKey');
