import {} from './store'
declare module './store' {}
