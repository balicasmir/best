import {} from './webrtc'
declare module './webrtc' {}
