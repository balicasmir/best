;(function(){

    var u, Gun = (''+u != typeof GUN)? (GUN||{chain:{}}) : require((''+u === typeof MODULE?'.':'')+'./gun', 1);
    Gun.chain.then = function(cb, opt){
      var gun = this, p = (new Promise(function(res, rej){
        gun.once(res, opt);
      }));
      return cb? p.then(cb) : p;
    }
  
}());