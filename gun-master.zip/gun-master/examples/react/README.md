You can use `todo.html` as a project template to get started with React + GUN.

It is an extremely simple in-memory only todo app that you can [try here](https://gunjs.herokuapp.com/react/todo.html).

There are some other simple examples in the `src` folder.

If you want to see next level stuff, check out any of [Nick's React apps](https://github.com/nmaro?utf8=%E2%9C%93&tab=repositories&q=gun&type=&language=).
